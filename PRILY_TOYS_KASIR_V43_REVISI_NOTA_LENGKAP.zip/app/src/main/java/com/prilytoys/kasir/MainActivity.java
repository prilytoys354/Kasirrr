package com.prilytoys.kasir;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT_CONNECT = 1001;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final int MAX_PRINT_ATTEMPTS = 3;
    private static final String PREFS = "printer_prefs";
    private static final String PREF_ADDRESS = "printer_address";

    private WebView webView;
    private String pendingPrintJson;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);

        webView.addJavascriptInterface(new AndroidPrinterBridge(), "AndroidPrinter");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleUrl(String url) {
        if (url != null && url.startsWith("my.bluetoothprint.scheme://")) {
            Toast.makeText(this, "Bluetooth Print lama tidak diperlukan. Gunakan printer Bluetooth yang sudah dipasangkan di Android.", Toast.LENGTH_LONG).show();
            return true;
        }
        return false;
    }

    private boolean hasBtPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBtPermission(String json) {
        pendingPrintJson = json;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runOnUiThread(() -> requestPermissions(
                    new String[]{
                            Manifest.permission.BLUETOOTH_CONNECT,
                            Manifest.permission.BLUETOOTH_SCAN
                    }, REQ_BT_CONNECT));
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT_CONNECT) {
            if (hasBtPermission() && pendingPrintJson != null) {
                String json = pendingPrintJson;
                pendingPrintJson = null;
                showPrinterChooser(json);
            } else {
                pendingPrintJson = null;
                notifyPrint(false, "Izin Bluetooth untuk koneksi dan pemindaian perangkat diperlukan.");
            }
        }
    }

    private void showPrinterChooser(final String json) {
        if (!hasBtPermission()) {
            requestBtPermission(json);
            return;
        }
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            notifyPrint(false, "HP ini tidak memiliki Bluetooth.");
            return;
        }
        if (!adapter.isEnabled()) {
            notifyPrint(false, "Bluetooth HP belum aktif. Aktifkan Bluetooth lalu coba cetak lagi.");
            return;
        }

        final List<BluetoothDevice> devices = new ArrayList<>(adapter.getBondedDevices());
        if (devices.isEmpty()) {
            notifyPrint(false, "Belum ada printer Bluetooth yang dipasangkan. Pasangkan printer di Pengaturan Bluetooth HP terlebih dahulu.");
            return;
        }

        // Setelah printer berhasil dipakai sekali, gunakan printer yang sama
        // secara otomatis agar tidak perlu memilih ulang setiap nota.
        String savedAddress = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_ADDRESS, "");
        if (!savedAddress.isEmpty()) {
            for (BluetoothDevice d : devices) {
                if (savedAddress.equalsIgnoreCase(d.getAddress())) {
                    printToDevice(d, json);
                    return;
                }
            }
        }

        String[] labels = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            BluetoothDevice d = devices.get(i);
            String name = d.getName();
            if (name == null || name.trim().isEmpty()) name = "Perangkat Bluetooth";
            labels[i] = name + "\n" + d.getAddress();
        }

        new AlertDialog.Builder(this)
                .setTitle("Pilih Printer Bluetooth")
                .setItems(labels, (dialog, which) -> printToDevice(devices.get(which), json))
                .setNegativeButton("Batal", null)
                .show();
    }

    private void printToDevice(final BluetoothDevice device, final String json) {
        new Thread(() -> {
            Exception lastError = null;
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter != null) adapter.cancelDiscovery();

                // Attempt 1: standard Bluetooth Serial Port Profile (SPP), secure.
                try {
                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                    sendEscPos(socket, json);
                    savePrinter(device);
                    notifyPrint(true, "Nota berhasil dikirim ke " + safeName(device));
                    return;
                } catch (Exception e) {
                    lastError = e;
                    closeSocket(socket);
                    socket = null;
                }

                // Attempt 2: SPP insecure. Some inexpensive thermal printers need this.
                try {
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                    sendEscPos(socket, json);
                    savePrinter(device);
                    notifyPrint(true, "Nota berhasil dikirim ke " + safeName(device));
                    return;
                } catch (Exception e) {
                    lastError = e;
                    closeSocket(socket);
                    socket = null;
                }

                // Attempt 3: many legacy ESC/POS printers expose RFCOMM channel 1.
                try {
                    java.lang.reflect.Method method = device.getClass().getMethod("createRfcommSocket", int.class);
                    socket = (BluetoothSocket) method.invoke(device, 1);
                    socket.connect();
                    sendEscPos(socket, json);
                    savePrinter(device);
                    notifyPrint(true, "Nota berhasil dikirim ke " + safeName(device));
                    return;
                } catch (Exception e) {
                    lastError = e;
                    closeSocket(socket);
                    socket = null;
                }

                String detail = lastError == null ? "koneksi tidak diketahui" : describePrintError(lastError);
                notifyPrint(false,
                        "Printer terdeteksi tetapi koneksi cetak gagal (" + detail + "). " +
                        "Pastikan printer tidak sedang dipakai HP/aplikasi lain dan mendukung Bluetooth SPP/ESC-POS.");
            } finally {
                closeSocket(socket);
            }
        }).start();
    }

    private void sendEscPos(BluetoothSocket socket, String json) throws Exception {
        if (socket == null || !socket.isConnected()) {
            throw new java.io.IOException("socket tidak terhubung");
        }
        OutputStream out = socket.getOutputStream();
        byte[] data = buildEscPos(json);
        // Kirim bertahap agar printer thermal murah tidak kehilangan data
        // ketika buffer Bluetooth-nya kecil.
        final int chunk = 256;
        for (int i = 0; i < data.length; i += chunk) {
            int len = Math.min(chunk, data.length - i);
            out.write(data, i, len);
            out.flush();
            Thread.sleep(35);
        }
        // Beri waktu buffer printer mengosongkan seluruh data sebelum socket ditutup.
        Thread.sleep(1200);
    }

    private void savePrinter(BluetoothDevice device) {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(PREF_ADDRESS, device.getAddress())
                    .apply();
        } catch (Exception ignored) {}
    }

    private void closeSocket(BluetoothSocket socket) {
        if (socket != null) {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private String describePrintError(Exception e) {
        Throwable t = e;
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        String msg = t.getMessage();
        if (msg == null || msg.trim().isEmpty()) msg = t.getClass().getSimpleName();
        msg = msg.replaceAll("\\s+", " ").trim();
        if (msg.length() > 90) msg = msg.substring(0, 90);
        return msg;
    }

    private String safeName(BluetoothDevice d) {
        try {
            String n = d.getName();
            return n == null ? "printer" : n;
        } catch (Exception e) { return "printer"; }
    }

    private byte[] buildEscPos(String json) throws Exception {
        JSONObject tx = new JSONObject(json);
        if (tx.has("requests")) return buildRequestEscPos(tx);
        if (tx.has("sales") || tx.has("cash")) return buildReportEscPos(tx);
        List<byte[]> chunks = new ArrayList<>();
        chunks.add(new byte[]{0x1B, 0x40});
        // Gunakan hanya perintah ESC/POS yang umum agar printer thermal murah
        // tidak salah menafsirkan perintah density/speed vendor tertentu.
        // Kejelasan dinaikkan dengan emphasized/bold, bukan command density
        // yang pada sebagian printer justru dapat tercetak sebagai karakter aneh.
        chunks.add(new byte[]{0x1B, 0x45, 0x01}); // emphasized/bold
        chunks.add(new byte[]{0x1B, 0x47, 0x01}); // double-strike, supported by common ESC/POS printers
        chunks.add(new byte[]{0x1B, 0x61, 0x01});
        chunks.add(new byte[]{0x1B, 0x45, 0x01});
        chunks.add(new byte[]{0x1B, 0x47, 0x01});
        chunks.add(text("PRILY TOYS\n"));
        chunks.add(new byte[]{0x1B, 0x45, 0x00});
        chunks.add(new byte[]{0x1B, 0x47, 0x00});
        chunks.add(text("GROSIR MAINAN MURAH\n"));
        chunks.add(text("082317812957\n"));
        chunks.add(text("NOTA PENJUALAN\n"));
        chunks.add(text("--------------------------------\n"));
        chunks.add(new byte[]{0x1B, 0x61, 0x00});
        chunks.add(new byte[]{0x1B, 0x45, 0x01});
        chunks.add(text("Nota: " + tx.optString("invoice") + "\n"));
        chunks.add(text("Tanggal: " + tx.optString("date") + " " + tx.optString("time") + "\n"));
        chunks.add(text("Pelanggan: " + tx.optString("customer") + "\n"));
        chunks.add(text("--------------------------------\n"));
        // Format nota: Nama Barang | Qty | Harga Satuan | Jumlah.
        // Qty diberi jarak dari nama barang; simbol @ tidak dicetak.
        chunks.add(text(formatItemHeader()));
        chunks.add(text("--------------------------------\n"));
        JSONArray items = tx.optJSONArray("items");
        if (items != null) {
            for (int i=0;i<items.length();i++) {
                JSONObject x=items.getJSONObject(i);
                int qty=x.optInt("qty",1); String name=x.optString("name"); long sub=x.optLong("price",0)*qty;
                chunks.add(text(formatItemLine(i + 1, qty, name, rupiahNumber(x.optLong("price",0)), rupiahNumber(sub))));
            }
        }
        chunks.add(text("--------------------------------\n"));
        int totalItems = 0;
        if (items != null) {
            for (int i=0;i<items.length();i++) {
                totalItems += Math.max(0, items.getJSONObject(i).optInt("qty",1));
            }
        }
        chunks.add(text(String.format("%-27s%15s\n", "JUMLAH ITEM", String.valueOf(totalItems))));
        chunks.add(new byte[]{0x1B, 0x61, 0x01});
        chunks.add(new byte[]{0x1B, 0x45, 0x01});
        chunks.add(new byte[]{0x1D, 0x21, 0x10});
        chunks.add(text("TOTAL\n"));
        chunks.add(text(rupiah(tx.optLong("total",0))+"\n"));
        chunks.add(new byte[]{0x1D, 0x21, 0x00});
        chunks.add(new byte[]{0x1B, 0x45, 0x00});
        chunks.add(new byte[]{0x1B, 0x47, 0x00});
        chunks.add(new byte[]{0x1B, 0x61, 0x00});
        chunks.add(text("--------------------------------\n"));
        chunks.add(new byte[]{0x1B,0x61,0x01});
        chunks.add(text("Terima kasih\nPRILY TOYS\n\n\n"));
        chunks.add(new byte[]{0x1B,0x45,0x00});
        // Jangan kirim perintah potong otomatis; banyak printer thermal 80 mm
        // murah tidak memiliki cutter dan dapat bereaksi aneh terhadap command ini.
        chunks.add(text("\n"));
        return join(chunks);
    }

    private String rupiahNumber(long value) {
        return String.format(java.util.Locale.US, "%,d", value).replace(',', '.');
    }

    private String formatItemHeader() {
        // Layout 32 karakter untuk printer thermal 58 mm:
        // Barang | Qty | Satuan | Jumlah.
        // Harga satuan tetap dicetak, tetapi tanpa simbol @.
        return String.format("%-12s%4s%8s%8s\n", "Barang", "Qty", "Satuan", "Jumlah");
    }

    private String formatItemLine(int no, int qty, String name, String unit, String amount) {
        // 32 karakter: 12 nama + 4 qty + 8 harga satuan + 8 jumlah.
        // Ada jarak yang jelas antara nama barang dan Qty.
        final int nameWidth = 12;
        final int qtyWidth = 4;
        final int unitWidth = 8;
        final int amountWidth = 8;
        String q = String.valueOf(qty);
        String n = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        String u = unit == null ? "0" : unit;
        String a = amount == null ? "0" : amount;
        if (u.length() > unitWidth) u = u.substring(u.length() - unitWidth);
        if (a.length() > amountWidth) a = a.substring(a.length() - amountWidth);
        if (n.length() > nameWidth) n = n.substring(0, Math.max(0, nameWidth - 1)).trim() + "…";
        return String.format("%-" + nameWidth + "s%" + qtyWidth + "s%" + unitWidth + "s%" + amountWidth + "s\n", n, q, u, a);
    }

    private byte[] buildRequestEscPos(JSONObject payload) throws Exception {
        List<byte[]> chunks = new ArrayList<>();
        chunks.add(new byte[]{0x1B,0x40});
        // Hanya gunakan command ESC/POS umum agar kompatibel dengan printer thermal.
        chunks.add(new byte[]{0x1B,0x45,0x01});
        chunks.add(new byte[]{0x1B,0x61,0x01});
        chunks.add(new byte[]{0x1B,0x45,0x01});
        chunks.add(text("PRILY TOYS\n"));
        chunks.add(new byte[]{0x1B,0x45,0x00});
        chunks.add(text("DAFTAR BELANJA / REQUEST\n"));
        chunks.add(text("082317812957\n"));
        chunks.add(text("--------------------------------\n"));
        chunks.add(new byte[]{0x1B,0x61,0x00});
        JSONArray arr = payload.optJSONArray("requests");
        if(arr != null) {
            for(int i=0;i<arr.length();i++) {
                JSONObject x=arr.getJSONObject(i);
                String name=x.optString("name","").replaceAll("\\s+"," ").trim();
                String customer=x.optString("customer","").replaceAll("\\s+"," ").trim();
                String line=String.format("%-3s%-24s", "□", truncate(name,24));
                if(!customer.isEmpty()) line += " " + truncate(customer,8);
                chunks.add(text(line+"\n"));
            }
        }
        chunks.add(text("--------------------------------\n"));
        chunks.add(text("Jumlah item: "+(arr==null?0:arr.length())+"\n"));
        chunks.add(text("\n\n"));
        chunks.add(text("\n"));
        return join(chunks);
    }

    private byte[] buildReportEscPos(JSONObject report) throws Exception {
        List<byte[]> chunks=new ArrayList<>();
        chunks.add(new byte[]{0x1B,0x40});
        // Hanya gunakan command ESC/POS umum agar kompatibel dengan printer thermal.
        chunks.add(new byte[]{0x1B,0x45,0x01});
        chunks.add(new byte[]{0x1B,0x61,0x01});
        chunks.add(new byte[]{0x1B,0x45,0x01}); chunks.add(text("PRILY TOYS\n"));
        chunks.add(new byte[]{0x1B,0x45,0x00}); chunks.add(text("LAPORAN TOKO\n"));
        chunks.add(text(report.optString("from")+" s/d "+report.optString("to")+"\n"));
        String cust=report.optString("customer",""); if(!cust.isEmpty()) chunks.add(text("Pelanggan: "+cust+"\n"));
        chunks.add(text("--------------------------------\n"));
        JSONArray sales=report.optJSONArray("sales"); long omzet=0;
        if(sales!=null){for(int i=0;i<sales.length();i++){JSONObject x=sales.getJSONObject(i);long total=x.optLong("total",0);omzet+=total;String name=x.optString("customer");chunks.add(text(String.format("%-10s %-10s %12s\n",x.optString("date"),truncate(name,10),rupiah(total))));}}
        chunks.add(text("--------------------------------\n")); chunks.add(text(String.format("%-12s %20s\n","OMSET",rupiah(omzet))));
        chunks.add(text("KAS / UANG\n"));
        JSONArray cash=report.optJSONArray("cash"); long saldo=0;
        if(cash!=null){for(int i=0;i<cash.length();i++){JSONObject x=cash.getJSONObject(i);long amt=x.optLong("amount",0);boolean in="in".equals(x.optString("type"));saldo += in?amt:-amt;String sign=in?"+":"-";chunks.add(text(String.format("%-10s %-14s %11s\n",x.optString("date"),truncate(x.optString("note"),14),sign+rupiah(amt))));}}
        chunks.add(text("--------------------------------\n")); chunks.add(text(String.format("%-12s %20s\n","SALDO",rupiah(saldo))));
        chunks.add(text("\n\n")); chunks.add(new byte[]{0x1D,0x56,0x00}); return join(chunks);
    }

    private String truncate(String s,int max){if(s==null)return "";s=s.replaceAll("\\s+"," ").trim();return s.length()>max?s.substring(0,max):s;}
    private byte[] join(List<byte[]> chunks){int total=0;for(byte[] c:chunks)total+=c.length;byte[] out=new byte[total];int pos=0;for(byte[] c:chunks){System.arraycopy(c,0,out,pos,c.length);pos+=c.length;}return out;}

    private byte[] text(String s) {
        // Printer thermal Bluetooth generik sering tidak memahami UTF-8.
        // Gunakan Windows-1252 untuk teks Latin dan ganti karakter non-ASCII
        // yang berpotensi membuat printer mencetak simbol/karakter aneh.
        String safe = s == null ? "" : s.replace("…", "...").replace("□", "[ ]");
        return safe.getBytes(java.nio.charset.Charset.forName("windows-1252"));
    }

    private String rupiah(long n) {
        String s = Long.toString(Math.max(0, n));
        StringBuilder out = new StringBuilder();
        int count = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            if (count == 3) { out.append('.'); count = 0; }
            out.append(s.charAt(i)); count++;
        }
        return "Rp " + out.reverse();
    }

    private String wrap(String s, int width) {
        if (s == null) return "\n";
        StringBuilder out = new StringBuilder();
        String rest = s.trim();
        while (rest.length() > width) {
            int cut = rest.lastIndexOf(' ', width);
            if (cut <= 0) cut = width;
            out.append(rest, 0, cut).append('\n');
            rest = rest.substring(cut).trim();
        }
        out.append(rest).append('\n');
        return out.toString();
    }

    private void notifyPrint(boolean ok, String message) {
        runOnUiThread(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            if (webView != null) {
                String js = "window.onNativePrintResult && window.onNativePrintResult(" + ok + "," + JSONObject.quote(message) + ");";
                webView.evaluateJavascript(js, null);
            }
        });
    }

    public class AndroidPrinterBridge {
        @JavascriptInterface
        public void printReceipt(String json) {
            if (!hasBtPermission()) requestBtPermission(json);
            else runOnUiThread(() -> showPrinterChooser(json));
        }
        @JavascriptInterface
        public void printReport(String json) {
            if (!hasBtPermission()) requestBtPermission(json);
            else runOnUiThread(() -> showPrinterChooser(json));
        }
        @JavascriptInterface
        public void printRequests(String json) {
            if (!hasBtPermission()) requestBtPermission(json);
            else runOnUiThread(() -> showPrinterChooser(json));
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
