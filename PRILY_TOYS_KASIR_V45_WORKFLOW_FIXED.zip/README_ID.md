# PRILY TOYS KASIR V41

Proyek Android untuk aplikasi kasir PRILY TOYS. APK dibuat otomatis melalui GitHub Actions.

## Cara build APK di GitHub

1. Buat repository GitHub baru.
2. Upload **isi folder ini** ke repository (bukan folder pembungkus tambahan).
3. Buka tab **Actions**.
4. Pilih workflow **Build PRILY TOYS KASIR V41**.
5. Klik **Run workflow** → **Run workflow**.
6. Setelah selesai, buka hasil workflow dan download artifact **PRILY-TOYS-KASIR-v41-APK**.
7. Ekstrak artifact dan install `app-debug.apk` di Android.

## Persyaratan

- Android Studio/Gradle menggunakan Java 17 untuk build lokal.
- GitHub Actions sudah dikonfigurasi menggunakan Java 17 dan Gradle 8.7.

## Catatan

Aplikasi menggunakan WebView lokal dan menyediakan bridge Java untuk pencetakan Bluetooth ESC/POS. Pada Android 12+, izin Bluetooth diminta saat diperlukan.
