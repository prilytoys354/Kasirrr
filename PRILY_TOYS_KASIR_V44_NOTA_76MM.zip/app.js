
const $=id=>document.getElementById(id);
const rupiah=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0);
const load=(k,d)=>JSON.parse(localStorage.getItem(k)||JSON.stringify(d));
const save=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
function nextTransactionNumber(){
  const n=+(localStorage.getItem('pt_next_invoice')||'1');
  localStorage.setItem('pt_next_invoice',String(n+1));
  return 'PT-'+String(n).padStart(5,'0');
}
function databaseStatus(){
  const count=load('pt_sales',[]).length;
  const inv=load('pt_inventory',[]).length;
  const el=$('storageStatus');
  if(el) el.textContent=`💾 Database lokal aktif • ${count} transaksi • ${inv} barang`;
}

function toast(msg){
 const t=$('toast'); if(!t)return;
 t.textContent=msg; t.classList.add('show');
 clearTimeout(window.__toastTimer);
 window.__toastTimer=setTimeout(()=>t.classList.remove('show'),2200);
}
function resetNote(){
 editingTransactionId=null;
 const banner=$('editModeBanner'); if(banner) banner.classList.remove('show');
 cart=[];
 $('customer').value='';
 $('paidAmount').value='';
 $('itemName').value='';
 $('qty').value=1;
 $('price').value='';
 $('barcodeInput').value='';
 $('barcodeStatus').textContent='';
 $('barcodeStatus').className='muted';
 $('suggestions').innerHTML='';
 renderCart();
 $('barcodeInput').focus();
 updatePayment();
}

// Kunci duplikasi nota: nota dianggap sama bila pelanggan, barang, harga,
// qty, total dan uang dibayar sama. Kunci ini hanya berlaku 60 detik agar
// transaksi yang benar-benar baru setelah satu menit tetap bisa disimpan.
function transactionSignature(tx){
 const items=(tx.items||[]).map(x=>({
   name:norm(x.name), qty:+x.qty||0, price:+x.price||0
 }));
 return JSON.stringify({
   customer:norm(tx.customer),
   items,
   total:+tx.total||0,
   paid:+tx.paid||0,
   change:+tx.change||0
 });
}
function findRecentDuplicate(tx, nowMs){
 const list=load('pt_sales',[]);
 const sig=transactionSignature(tx);
 for(let i=list.length-1;i>=0;i--){
   const old=list[i];
   const oldMs=+(old.createdAt||old.id||0);
   if(!oldMs) continue;
   const age=nowMs-oldMs;
   if(age<0) continue;
   if(age>60000) break;
   if(transactionSignature(old)===sig) return old;
 }
 return null;
}
function bluetoothPrintJson(tx){
  // Native Android printer bridge: prints directly to a paired Bluetooth thermal printer.
  if(window.AndroidPrinter && typeof window.AndroidPrinter.printReceipt === 'function'){
    try{
      window.AndroidPrinter.printReceipt(JSON.stringify(tx));
      return true;
    }catch(err){
      console.error(err);
    }
  }

  // Optional legacy Bluetooth Print app fallback.
  const url=(localStorage.getItem('pt_bt_response_url')||'').trim();
  if(!url) return false;
  window.location.href='my.bluetoothprint.scheme://'+url;
  return true;
}

function printReceipt(tx){
  // Native Android printer prints the same compact one-line-per-item format.
  if(bluetoothPrintJson(tx)) return;
  let old=document.getElementById('printReceiptArea'); if(old) old.remove();
  const rows=tx.items.map(x=>{
    const qty=String(x.qty); const total=rupiah(x.qty*x.price);
    return `<tr><td class="receipt-name">${esc(x.name)}</td><td class="receipt-qty" style="width:38px;padding-left:8px">${esc(qty)}</td><td class="receipt-amount" style="width:32%">${total}</td></tr>`;
  }).join('');
  const area=document.createElement('div'); area.id='printReceiptArea';
  area.innerHTML=`<div class="receipt-paper">
    <h2>PRILY TOYS</h2><div class="receipt-center"><b>GROSIR MAINAN MURAH</b><br>082317812957</div><hr>
    <div>Nota: <b>${esc(tx.invoice)}</b></div><div>Tanggal: ${esc(tx.date)} ${esc(tx.time||'')}</div><div>Pelanggan: ${esc(tx.customer)}</div><hr>
    <table><tbody>${rows}</tbody></table><hr>
    <div class="receipt-line"><span>JUMLAH ITEM</span><span>${(tx.items||[]).reduce((s,x)=>s+(+x.qty||0),0)}</span></div>
    <div class="receipt-total-center">TOTAL<b>${rupiah(tx.total)}</b></div>
    <div class="receipt-line"><span>Bayar</span><span>${rupiah(tx.paid)}</span></div>
    <div class="receipt-line"><span>Kembalian</span><span>${rupiah(tx.change)}</span></div><hr>
    <div class="receipt-center">Terima kasih<br>PRILY TOYS</div></div>`;
  document.body.appendChild(area);
  setTimeout(()=>{window.print();setTimeout(()=>area.remove(),700)},150);
}

function initBluetoothPrintSettings(){
  const input=$('btResponseUrl');
  if(input) input.value=localStorage.getItem('pt_bt_response_url')||'';
  const saveBtn=$('btSaveUrl');
  if(saveBtn) saveBtn.onclick=()=>{
    const v=(input.value||'').trim();
    if(v && !/^https?:\/\//i.test(v)){
      alert('URL harus diawali http:// atau https://');
      return;
    }
    localStorage.setItem('pt_bt_response_url',v);
    toast(v?'URL Bluetooth Print tersimpan.':'URL Bluetooth Print dihapus.');
  };
  const openBtn=$('btOpen');
  if(openBtn) openBtn.onclick=()=>{
    window.location.href='my.bluetoothprint.scheme://';
  };

  const testBtn=$('btTest');
  if(testBtn) testBtn.onclick=()=>{
    const testTx={
      invoice:'TEST',
      date:new Date().toISOString().slice(0,10),
      time:new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}),
      customer:'Tes Printer',
      items:[{name:'TES BLUETOOTH PRINT',qty:1,price:1000}],
      total:1000,paid:1000,change:0
    };
    bluetoothPrintJson(testTx);
  };
}

let inventory=load('pt_inventory',[]);
let sales=load('pt_sales',[]);
let requests=load('pt_requests',[]);
let cart=[];
let lastSavedCart=[];
let editingTransactionId=null;

function norm(s){
 return String(s||'')
   .toLowerCase()
   .normalize('NFKD')
   .replace(/[\u0300-\u036f]/g,'')
   .replace(/[^a-z0-9]+/g,'')
   .trim();
}
function similarity(a,b){
 a=norm(a); b=norm(b);
 if(!a||!b)return 0;
 if(a===b)return 1;
 if(a.includes(b)||b.includes(a)) return Math.min(a.length,b.length)/Math.max(a.length,b.length)*0.98+0.02;
 const rows=a.length+1, cols=b.length+1;
 const prev=Array(cols); for(let j=0;j<cols;j++)prev[j]=j;
 for(let i=1;i<rows;i++){
   const cur=[i];
   for(let j=1;j<cols;j++){
     const cost=a[i-1]===b[j-1]?0:1;
     cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+cost);
   }
   for(let j=0;j<cols;j++)prev[j]=cur[j];
 }
 return 1-(prev[b.length]/Math.max(a.length,b.length));
}
function bestInventoryMatches(query,limit=8){
 const q=norm(query);
 if(!q)return [];
 return inventory
   .map(x=>({x,score:similarity(q,x.name)}))
   .filter(o=>o.score>=0.68)
   .sort((a,b)=>b.score-a.score)
   .slice(0,limit)
   .map(o=>o.x);
}
function updatePayment(){
 const total=cart.reduce((a,x)=>a+x.qty*x.price,0);
 const paid=+$('paidAmount').value||0;
 const diff=paid-total;
 $('changeAmount').textContent=rupiah(Math.max(0,diff));
 if(!cart.length){$('paymentMessage').textContent='';return}
 if(!paid){$('paymentMessage').textContent='Masukkan jumlah uang pelanggan.'}
 else if(diff<0){$('paymentMessage').textContent='Uang masih kurang '+rupiah(Math.abs(diff));}
 else if(diff===0){$('paymentMessage').textContent='Uang pas. Tidak ada kembalian.';}
 else{$('paymentMessage').textContent='Kembalian siap diberikan.';}
}
function renderCart(){
  $('cart').innerHTML=cart.length?cart.map((x,i)=>`<div class="item">
  <div class="receipt-grid">
    <div class="receipt-name"><strong>${esc(x.name)}</strong></div>
    <div class="receipt-qty"><input aria-label="Qty" type="number" min="1" value="${x.qty}" onchange="editQty(${i},this.value)"></div>
    <div class="receipt-price"><input aria-label="Harga" type="number" min="0" value="${x.price}" onchange="editPrice(${i},this.value)"></div>
    <div class="receipt-subtotal"><strong>${rupiah(x.qty*x.price)}</strong></div>
    <button class="icon-delete no-print" aria-label="Hapus barang" onclick="removeCart(${i})">🗑️</button>
  </div></div>`).join(''):'<div class="card empty">Belum ada barang di nota.</div>';
  $('cartTotal').textContent=rupiah(cart.reduce((a,x)=>a+x.qty*x.price,0));
  updatePayment();
}
function removeCart(i){cart.splice(i,1);renderCart()}
function editQty(i,v){cart[i].qty=Math.max(1,+v||1);renderCart()}
function editPrice(i,v){cart[i].price=Math.max(0,+v||0);renderCart()}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}

function showSuggestions(){
 const q=$('itemName').value.trim();
 if(!q){$('suggestions').innerHTML='';return}
 const hits=bestInventoryMatches(q,8);
 $('suggestions').innerHTML=hits.length
   ? `<div class="suggest">${hits.map((x,i)=>`<button type="button" class="suggest-item" data-index="${i}">${esc(x.name)} <span>— <b>${rupiah(x.price)}</b></span></button>`).join('')}</div>`
   : '';
 document.querySelectorAll('.suggest-item').forEach((btn,i)=>{
   const x=hits[i];
   btn.addEventListener('mousedown',e=>e.preventDefault());
   btn.addEventListener('click',e=>{e.preventDefault();pickItem(x.name,x.price);});
 });
}

function findBarcodeItem(code){
 const b=String(code||'').replace(/\\D/g,'').trim();
 if(!b)return null;
 return inventory.find(x=>String(x.barcode||'').replace(/\\D/g,'')===b)||null;
}
function setBarcodeStatus(msg,kind){
 const el=$('barcodeStatus'); if(!el)return;
 el.textContent=msg||'';
 el.className=kind==='ok'?'barcode-status-ok':(kind==='warn'?'barcode-status-warn':'muted');
}
function handleBarcodeInput(){
 const code=String($('barcodeInput').value||'').replace(/\\D/g,'').trim();
 $('barcodeInput').value=code;
 if(!code){setBarcodeStatus('');return}
 const item=findBarcodeItem(code);
 if(item){
   $('itemName').value=item.name;
   $('qty').value=1;
   $('price').value=Number(item.price)||0;
   $('suggestions').innerHTML='';
   setBarcodeStatus('✓ Barcode ditemukan: '+item.name+' • '+rupiah(item.price),'ok');
   addItem();
 }else{
   setBarcodeStatus('Barcode belum terdaftar. Silakan input nama barang dan harga secara manual.','warn');
   $('itemName').focus();
 }
}
function pickItem(name,price){
  $('itemName').value=name;
  $('qty').value=1;
  $('price').value=price;
  $('suggestions').innerHTML='';
  $('itemName').blur();
  $('qty').focus();
  $('qty').select();
}
function addItem(){
 const typedName=$('itemName').value.trim(),qty=Math.max(1,+$('qty').value||1);
 if(!typedName){$('itemName').focus();return}
 const scannedBarcode=String($('barcodeInput').value||'').replace(/\\D/g,'').trim();
 let price=+$('price').value;
 const exact=inventory.find(x=>norm(x.name)===norm(typedName));
 const barcodeItem=scannedBarcode?findBarcodeItem(scannedBarcode):null;
 const close=exact||barcodeItem||bestInventoryMatches(typedName,1)[0];
 if((!price||price<0)&&close)price=close.price;
 if(!Number.isFinite(price)||price<0){alert('Masukkan harga barang.');$('price').focus();return}
 const finalName=close && similarity(typedName,close.name)>=0.78 ? close.name : typedName;
 const existing=cart.find(x=>{
   if(scannedBarcode && x.barcode) return String(x.barcode)===scannedBarcode;
   return norm(x.name)===norm(finalName) && Number(x.price)===Number(price);
 });
 if(existing){
   existing.qty+=qty;
   if(scannedBarcode) existing.barcode=scannedBarcode;
 }else{
   cart.push({name:finalName,qty,price,barcode:scannedBarcode||((close&&close.barcode)||'')});
 }
 renderCart();
 $('itemName').value='';$('qty').value=1;$('price').value='';
 $('barcodeInput').value='';$('barcodeStatus').textContent='';$('barcodeStatus').className='muted';
 $('suggestions').innerHTML='';$('itemName').focus();
}
function editTransaction(id){
 const list=load('pt_sales',[]);
 const tx=list.find(x=>String(x.id)===String(id));
 if(!tx){toast('Nota tidak ditemukan.');return}
 editingTransactionId=tx.id;
 cart=(tx.items||[]).map(x=>({...x}));
 $('customer').value=tx.customer||'';
 $('paidAmount').value=tx.paid||'';
 $('itemName').value=''; $('qty').value=1; $('price').value=''; $('barcodeInput').value='';
 $('barcodeStatus').textContent=''; $('barcodeStatus').className='muted'; $('suggestions').innerHTML='';
 const banner=$('editModeBanner'); if(banner){banner.classList.add('show');$('editInvoiceLabel').textContent=tx.invoice||'';}
 renderCart();
 go('kasir');
 window.scrollTo({top:0,behavior:'smooth'});
 toast('Nota '+(tx.invoice||'')+' siap direvisi.');
}
function cancelEditTransaction(){
 editingTransactionId=null;
 const banner=$('editModeBanner'); if(banner) banner.classList.remove('show');
 resetNote();
 toast('Revisi dibatalkan. Nota baru siap digunakan.');
}

function saveTransaction(print=false){
 if(!cart.length){alert('Nota masih kosong.');return}
 const saveBtn=$('saveOnly'), printBtn=$('savePrint');
 saveBtn.disabled=true; printBtn.disabled=true;
 try{
   const now=new Date();
   const nowMs=Date.now();
   const date=now.toISOString().slice(0,10);
   const customer=$('customer').value.trim()||'Pelanggan Umum';
   const total=cart.reduce((a,x)=>a+x.qty*x.price,0);
   const paid=+$('paidAmount').value||0;
   if(paid>0 && paid<total){
     alert('Uang dibayar masih kurang '+rupiah(total-paid)+'.');
     $('paidAmount').focus();
     return;
   }

   sales=load('pt_sales',[]);
   let tx;
   if(editingTransactionId!==null){
     const idx=sales.findIndex(x=>String(x.id)===String(editingTransactionId));
     if(idx<0){throw new Error('Nota yang direvisi tidak ditemukan.');}
     const old=sales[idx];
     tx={
       ...old,
       customer, items:cart.map(x=>({...x})), total, paid,
       change:Math.max(0,paid-total),
       revisedAt:nowMs
     };
     sales[idx]=tx;
     save('pt_sales',sales);
   }else{
     // Cek duplikasi hanya untuk transaksi baru. Revisi tidak boleh membuat
     // transaksi kedua; nota lama memang sengaja diganti.
     const candidate={
       customer, items:cart.map(x=>({...x})), total, paid,
       change:Math.max(0,paid-total)
     };
     const duplicate=findRecentDuplicate(candidate,nowMs);
     if(duplicate){
       databaseStatus();
       if(print) printReceipt(duplicate);
       toast(print
         ? 'Nota sama sudah tersimpan < 1 menit lalu • tidak menambah omset • mencetak ulang'
         : 'Nota sama sudah tersimpan < 1 menit lalu • tidak menambah omset');
       return;
     }
     const invoice=nextTransactionNumber();
     tx={
       id:nowMs, createdAt:nowMs, invoice, date,
       time:now.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}),
       customer, items:cart.map(x=>({...x})), total, paid,
       change:Math.max(0,paid-total)
     };
     sales.push(tx);
     save('pt_sales',sales);
   }

   inventory=load('pt_inventory',[]);
   tx.items.forEach(x=>{
     const f=inventory.find(y=>norm(y.name)===norm(x.name));
     if(f){
       f.price=x.price;
       if(x.barcode) f.barcode=String(x.barcode);
     }else{
       inventory.push({name:x.name,price:x.price,barcode:x.barcode||''});
     }
   });
   save('pt_inventory',inventory);

   // Verify both main records before reporting success.
   const savedSales=load('pt_sales',[]);
   const savedInv=load('pt_inventory',[]);
   if(!savedSales.some(x=>x.id===tx.id)) throw new Error('Transaksi belum tersimpan.');
   if(tx.items.some(x=>!savedInv.some(y=>norm(y.name)===norm(x.name)))) throw new Error('Memory barang belum tersimpan.');

   sales=savedSales; inventory=savedInv;
   const wasEditing=editingTransactionId!==null;
   editingTransactionId=null;
   const editBanner=$('editModeBanner'); if(editBanner) editBanner.classList.remove('show');

   // PENTING: setelah simpan, lembar kasir TIDAK dikosongkan lagi.
   // Pengguna mengosongkannya hanya lewat ikon 📝 Nota Baru.
   databaseStatus();
   try { renderInventory(); } catch(e) { console.warn('Inventory refresh skipped:', e); }
   try { renderReports(); } catch(e) { console.warn('Report refresh skipped:', e); }

   // Simpan dulu, lalu cetak. Isi nota tetap berada di layar sehingga
   // pengguna dapat mencoba mencetak ulang tanpa kehilangan nota.
   if(print) printReceipt(tx);
   toast(wasEditing
     ? (print ? 'Revisi nota tersimpan menggantikan data lama • mencetak struk' : 'Revisi nota tersimpan menggantikan data lama')
     : (print ? 'Transaksi tersimpan • nota tetap di layar • mencetak struk' : 'Transaksi tersimpan • nota tetap di layar'));
 }catch(err){
   console.error(err);
   alert('Gagal menyimpan transaksi. Silakan coba lagi.');
 }finally{
   saveBtn.disabled=false; printBtn.disabled=false;
 }
}

function renderMemorySuggestions(){
 const host=$('memorySuggestions'); if(!host)return;
 const q=$('searchItem').value.trim();
 const hits=q?bestInventoryMatches(q,10):[];
 host.innerHTML=hits.length
   ? `<div class="memory-suggestion-list">${hits.map((x,i)=>`<button type="button" class="memory-suggestion" data-memory-index="${i}"><span class="memory-suggestion-name">${esc(x.name)}</span><span class="memory-suggestion-price">${rupiah(x.price)}</span></button>`).join('')}</div>`
   : '';
 host.querySelectorAll('.memory-suggestion').forEach((btn,i)=>{
   btn.addEventListener('click',()=>{
     const x=hits[i]; if(!x)return;
     $('searchItem').value=x.name;$('price').value=x.price;$('itemName').value=x.name;$('qty').value=1;host.innerHTML='';$('itemName').focus();
   });
 });
}

function renderInventory(){
 const q=$('searchItem').value.trim();
 const arr=(q?bestInventoryMatches(q,50):inventory.slice()).sort((a,b)=>a.name.localeCompare(b.name,'id'));
 $('inventory').innerHTML=arr.length
 ? arr.map(x=>{const idx=inventory.indexOf(x);return `<div class="item" data-inventory-index="${idx}">
   <div class="itemhead"><strong>${esc(x.name)}</strong><strong>${rupiah(x.price)}</strong></div>
   ${x.barcode?`<div class="inventory-barcode">Barcode: ${esc(x.barcode)}</div>`:`<div class="inventory-barcode">Barcode: belum diatur</div>`}
   <div class="actions no-print"><button type="button" class="btn primary edit-inv" data-index="${idx}">✏️ Edit Harga</button></div>
 </div>`}).join('')
 : '<div class="card empty">Belum ada barang tersimpan.</div>';
 document.querySelectorAll('.edit-inv').forEach(btn=>{
   btn.addEventListener('click',()=>editInv(Number(btn.dataset.index)));
 });
 renderMemorySuggestions();
}
let editingInventoryIndex=-1;
function editInv(i){
 const item=inventory[i];
 if(!item){toast('Barang tidak ditemukan.');return}
 editingInventoryIndex=i;
 $('priceEditItemName').textContent=item.name;
 $('priceEditInput').value=Number(item.price)||0;
 $('priceEditModal').classList.add('show');
 setTimeout(()=>{$('priceEditInput').focus();$('priceEditInput').select()},80);
}
function closePriceEdit(){
 editingInventoryIndex=-1;
 $('priceEditModal').classList.remove('show');
}
function savePriceEdit(){
 const i=editingInventoryIndex;
 const item=inventory[i];
 if(!item){closePriceEdit();toast('Barang tidak ditemukan.');return}
 const raw=String($('priceEditInput').value||'').replace(/[^0-9]/g,'');
 if(!raw){alert('Harga tidak valid.');$('priceEditInput').focus();return}
 const next=Math.max(0,Number(raw));
 if(!Number.isFinite(next)){alert('Harga tidak valid.');$('priceEditInput').focus();return}
 inventory[i]={...item,price:next};
 save('pt_inventory',inventory);
 // Update the current cashier price too when editing the same item.
 if(norm($('itemName').value)===norm(item.name)) $('price').value=next;
 // Update any matching item already on the current receipt.
 cart.forEach(x=>{if(norm(x.name)===norm(item.name)) x.price=next;});
 renderInventory();
 renderCart();
 databaseStatus();
 closePriceEdit();
 toast('Harga '+item.name+' berhasil diperbarui.');
}

function dateRange(){
 let from=$('fromDate').value,to=$('toDate').value;
 const today=new Date().toISOString().slice(0,10); from=from||today; to=to||today;
 if(from>to){const t=from;from=to;to=t;}
 return {from,to};
}
function customerKey(s){return norm(s)}
function dateFilter(){const r=dateRange();return sales.filter(s=>s.date>=r.from&&s.date<=r.to)}
function refreshData(){sales=load('pt_sales',[]);inventory=load('pt_inventory',[]);requests=load('pt_requests',[])}
function renderReports(){
 const range=dateRange();
 const wanted=customerKey($('customerFilter')?.value||'');
 let data=sales.filter(s=>s.date>=range.from&&s.date<=range.to);
 if(wanted) data=data.filter(s=>customerKey(s.customer)===wanted);
 const total=data.reduce((a,s)=>a+s.total,0);
 $('report').innerHTML=`<div class="kpis"><div class="kpi">Total Omset<b>${rupiah(total)}</b></div><div class="kpi">Transaksi<b>${data.length}</b></div><div class="kpi">Rata-rata<b>${rupiah(data.length?total/data.length:0)}</b></div></div>`;
 const hist=[...data].sort((a,b)=>b.id-a.id);
 $('transactionHistory').innerHTML=hist.length?`<table><tr><th>Tanggal</th><th>No. Nota</th><th>Pelanggan</th><th>Barang</th><th class="num-right">Total</th></tr>${hist.map(s=>{const names=s.items.map(x=>`${esc(x.name)} (${x.qty})`).join(', ');return `<tr><td>${s.date}</td><td><button type="button" class="invoice-link" onclick="editTransaction('${String(s.id)}')">${esc(s.invoice)}</button></td><td>${esc(s.customer)}</td><td>${names}</td><td class="num-right"><b>${rupiah(s.total)}</b></td></tr>`}).join('')}</table>`:'<div class="empty">Belum ada transaksi tersimpan pada periode ini.</div>';
 const map={}; data.forEach(s=>s.items.forEach(x=>{const k=norm(x.name);const found=Object.keys(map).find(y=>norm(y)===k);if(found)map[found]+=x.qty;else map[x.name]=x.qty}));
 const best=Object.entries(map).sort((a,b)=>b[1]-a[1]);
 $('bestSeller').innerHTML=best.length?`<table><tr><th>Rank</th><th>Barang</th><th class="num-right">Terjual</th></tr>${best.map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x[0])}</td><td class="num-right">${x[1]} pcs</td></tr>`).join('')}</table>`:'<div class="empty">Belum ada penjualan pada periode ini.</div>';
 const cm={}; data.forEach(s=>{const key=customerKey(s.customer);if(!cm[key])cm[key]={name:s.customer,total:0,count:0};cm[key].total+=s.total;cm[key].count++});
 const cs=Object.values(cm).sort((a,b)=>b.total-a.total);
 $('customersReport').innerHTML=cs.length?`<table><tr><th>Pelanggan</th><th class="num-right">Transaksi</th><th class="num-right">Total Belanja</th></tr>${cs.map(x=>`<tr><td>${esc(x.name)}</td><td class="num-right">${x.count}</td><td class="num-right"><b>${rupiah(x.total)}</b></td></tr>`).join('')}</table>`:'<div class="empty">Belum ada transaksi untuk pelanggan/periode ini.</div>';
 renderCashReport(range);
}
function loadCash(){return load('pt_cash',[])}
function saveCashEntry(){
 const note=$('cashNote').value.trim(),category=$('cashCategory').value.trim()||'Lain-lain',amount=Math.max(0,+$('cashAmount').value||0),type=window.__cashType||'in';
 if(!note){$('cashNote').focus();return} if(!amount){$('cashAmount').focus();return}
 const arr=loadCash(); arr.push({id:Date.now(),date:new Date().toISOString().slice(0,10),note,category,amount,type}); save('pt_cash',arr);
 $('cashNote').value='';$('cashCategory').value='';$('cashAmount').value=''; toast('Catatan kas tersimpan.'); renderCashReport(dateRange());
}
function setCashType(type){window.__cashType=type;$('cashInBtn').classList.toggle('active',type==='in');$('cashInBtn').classList.toggle('in',type==='in');$('cashOutBtn').classList.toggle('active',type==='out');$('cashOutBtn').classList.toggle('out',type==='out')}
function renderCashReport(range){
 const all=loadCash().sort((a,b)=>(a.date+a.id).localeCompare(b.date+b.id));
 const before=all.filter(x=>x.date<range.from).reduce((a,x)=>a+(x.type==='in'?x.amount:-x.amount),0);
 const rows=all.filter(x=>x.date>=range.from&&x.date<=range.to).sort((a,b)=>a.id-b.id);
 let saldo=before,totalIn=0,totalOut=0; const cats={};
 const body=rows.map(x=>{const delta=x.type==='in'?x.amount:-x.amount;saldo+=delta;if(x.type==='in')totalIn+=x.amount;else{totalOut+=x.amount;cats[x.category]=(cats[x.category]||0)+x.amount}const cls=x.type==='in'?'amount-in':'amount-out';const sign=x.type==='in'?'+':'−';return `<tr><td>${x.date}</td><td>${esc(x.note)}</td><td class="${cls}">${sign} ${rupiah(x.amount)}</td><td class="num-right">${rupiah(saldo)}</td></tr>`}).join('');
 const catRows=Object.entries(cats).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<tr><td>${esc(k)}</td><td class="num-right"><b>${rupiah(v)}</b></td></tr>`).join('');
 $('cashReport').innerHTML=`<div class="cash-summary"><div class="kpi in">Uang Masuk<b>${rupiah(totalIn)}</b></div><div class="kpi out">Uang Keluar<b>${rupiah(totalOut)}</b></div><div class="kpi">Saldo Akhir<b>${rupiah(saldo)}</b></div></div><div class="small muted" style="margin:10px 0">Periode ${range.from} s/d ${range.to}</div>${rows.length?`<table class="cash-table"><tr><th>Tanggal</th><th>Keterangan</th><th>Jumlah</th><th>Saldo</th></tr>${body}</table>`:'<div class="empty">Belum ada catatan kas pada periode ini.</div>'}<h4>Pengeluaran berdasarkan kategori</h4>${catRows?`<table><tr><th>Kategori</th><th class="num-right">Total Pengeluaran</th></tr>${catRows}</table>`:'<div class="empty">Belum ada pengeluaran pada periode ini.</div>'}`;
}
function printReport(){
 const range=dateRange(); const wanted=customerKey($('customerFilter')?.value||''); let data=sales.filter(s=>s.date>=range.from&&s.date<=range.to); if(wanted)data=data.filter(s=>customerKey(s.customer)===wanted);
 const cash=loadCash().filter(x=>x.date>=range.from&&x.date<=range.to);
 const payload={from:range.from,to:range.to,customer:wanted,sales:data,cash};
 if(window.AndroidPrinter&&typeof window.AndroidPrinter.printReport==='function'){try{window.AndroidPrinter.printReport(JSON.stringify(payload));return}catch(e){console.error(e)}}
 let old=document.getElementById('printReportArea');if(old)old.remove();const div=document.createElement('div');div.id='printReportArea';
 const total=data.reduce((a,x)=>a+x.total,0);const rows=data.map(x=>`<tr><td>${x.date}</td><td>${esc(x.customer)}</td><td style="text-align:right">${rupiah(x.total)}</td></tr>`).join('');const crows=cash.map(x=>`<tr><td>${x.date}</td><td>${esc(x.note)}</td><td style="text-align:right">${x.type==='in'?'+':'−'} ${rupiah(x.amount)}</td></tr>`).join('');
 div.innerHTML=`<div class="receipt-paper"><h2>PRILY TOYS</h2><div class="receipt-center">LAPORAN ${range.from} s/d ${range.to}</div><hr><b>Omset: ${rupiah(total)}</b><table><tr><th>Tanggal</th><th>Pelanggan</th><th>Total</th></tr>${rows}</table><hr><b>KAS / UANG</b><table><tr><th>Tanggal</th><th>Keterangan</th><th>Jumlah</th></tr>${crows}</table></div>`;document.body.appendChild(div);setTimeout(()=>{window.print();setTimeout(()=>div.remove(),700)},150)
}
function renderRequests(history=false){
 const active=requests.filter(x=>!x.done), arr=history?requests.filter(x=>x.done):active;
 $('requests').innerHTML=arr.length?arr.map((x)=>`<div class="item"><div class="itemhead"><strong>${esc(x.name)}</strong><span class="muted">${x.date}</span></div><div>${esc(x.customer||'-')}</div>${!history?`<div class="actions no-print"><button class="btn success" onclick="completeRequest(${x.id})">☑ Sudah Dibeli</button></div>`:'<div class="muted">Sudah dibeli</div>'}</div>`).join(''):'<div class="empty">Tidak ada request.</div>';
}
function completeRequest(id){const x=requests.find(x=>x.id===id);if(x)x.done=true;save('pt_requests',requests);renderRequests(false)}
function addRequest(){const name=$('reqName').value.trim();if(!name){$('reqName').focus();return}requests.push({id:Date.now(),name,customer:$('reqCustomer').value.trim(),date:new Date().toISOString().slice(0,10),done:false});save('pt_requests',requests);$('reqName').value='';$('reqCustomer').value='';renderRequests(false);$('reqName').focus()}
function printRequests(){
 const active=requests.filter(x=>!x.done);
 if(!active.length){alert('Daftar request aktif kosong.');return}
 const payload={requests:active};
 if(window.AndroidPrinter&&typeof window.AndroidPrinter.printRequests==='function'){
   try{window.AndroidPrinter.printRequests(JSON.stringify(payload));return}catch(e){console.error(e)}
 }
 let old=document.getElementById('printRequestArea');if(old)old.remove();
 const div=document.createElement('div');div.id='printRequestArea';
 const rows=active.map(x=>`<tr><td style="width:28px">□</td><td>${esc(x.name)}</td><td>${esc(x.customer||'')}</td></tr>`).join('');
 div.innerHTML=`<div class="receipt-paper"><h2>PRILY TOYS</h2><div class="receipt-center"><b>DAFTAR BELANJA / REQUEST</b><br>082317812957</div><hr><table><tbody>${rows}</tbody></table><hr><div>Jumlah item: ${active.length}</div></div>`;
 document.body.appendChild(div);
 setTimeout(()=>{window.print();setTimeout(()=>div.remove(),700)},150);
}
function go(page){
 document.querySelectorAll('.page').forEach(x=>x.classList.toggle('active',x.id===page));
 document.querySelectorAll('nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===page));
 refreshData();
 if(page==='barang')renderInventory();
 if(page==='laporan')renderReports();
 if(page==='request')renderRequests(false);
}

document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));
$('barcodeInput').addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();handleBarcodeInput();}
});
$('barcodeInput').addEventListener('input',()=>{
  const v=String($('barcodeInput').value||'').replace(/\D/g,'');
  $('barcodeInput').value=v;
});
$('itemName').addEventListener('input',showSuggestions);
$('addItem').onclick=addItem;
$('customer').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('itemName').focus()}});
$('paidAmount').addEventListener('input',updatePayment);
$('paidAmount').addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();$('saveOnly').focus();}
});
$('itemName').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const first=inventory.find(x=>norm(x.name)===norm($('itemName').value))||bestInventoryMatches($('itemName').value,1)[0];if(first&&similarity($('itemName').value,first.name)>=0.68){pickItem(first.name,first.price)}else $('qty').focus()}});
$('qty').addEventListener('focus',()=>{
  if($('qty').value==='1') $('qty').select();
});
$('qty').addEventListener('click',()=>{
  if($('qty').value==='1') $('qty').select();
});
$('qty').addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();$('price').focus()}
});
$('price').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addItem()}});
const clearCartBtn=$('clearCart');
if(clearCartBtn){
  clearCartBtn.onclick=()=>{
    if(cart.length&&confirm('Kosongkan semua barang di nota?')){
      resetNote();
      toast('Nota dikosongkan • nota baru siap digunakan.');
    }
  };
}
const newNotaDirect=$('newNotaDirect');
if(newNotaDirect){
  newNotaDirect.addEventListener('click',e=>{
    e.preventDefault();
    if(cart.length && !confirm('Mulai nota baru? Isi nota saat ini akan dikosongkan. Pastikan nota sudah selesai disimpan/cetak.')) return;
    resetNote();
    toast('Nota dikosongkan • nota baru siap digunakan.');
  });
}
$('savePrint').onclick=()=>saveTransaction(true);
$('savePriceEdit').onclick=savePriceEdit;
$('cancelPriceEdit').onclick=closePriceEdit;
$('priceEditModal').addEventListener('click',e=>{if(e.target===$('priceEditModal'))closePriceEdit()});
$('priceEditInput').addEventListener('keydown',e=>{
  if(e.key==='Enter'){e.preventDefault();savePriceEdit();}
  if(e.key==='Escape'){e.preventDefault();closePriceEdit();}
});
$('saveOnly').onclick=()=>saveTransaction(false);
// Tombol modal lama tidak lagi dipakai: setelah simpan nota tetap berada
// di layar. Pengosongan nota hanya melalui ikon 📝 Nota Baru.
$('newNota').onclick=()=>{ $('modal').classList.remove('show'); resetNote(); toast('Nota dikosongkan • nota baru siap digunakan.'); };
$('keepNota').onclick=()=>{ $('modal').classList.remove('show'); $('itemName').focus(); };
$('searchItem').oninput=()=>{renderInventory();renderMemorySuggestions()};
$('showReport').onclick=()=>{refreshData();renderReports();databaseStatus();toast('Laporan diperbarui.');};
$('verifyDb').onclick=()=>{refreshData();const cash=loadCash();databaseStatus();const last=sales.length?sales[sales.length-1]:null;alert(`Database OK\nTransaksi: ${sales.length}\nBarang: ${inventory.length}\nCatatan kas: ${cash.length}\n${last?`Terakhir: ${last.invoice} • ${rupiah(last.total)}`:'Belum ada transaksi.'}`);};
$('printReport').onclick=printReport;
$('saveCash').onclick=saveCashEntry;
$('cashInBtn').onclick=()=>setCashType('in');$('cashOutBtn').onclick=()=>setCashType('out');
$('addRequest').onclick=addRequest;$('printRequests').onclick=printRequests;$('showHistory').onclick=()=>renderRequests(true);
$('reqName').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('reqCustomer').focus()}});
$('reqCustomer').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();addRequest()}});

const today=new Date().toISOString().slice(0,10);$('fromDate').value=today;$('toDate').value=today; setCashType('in');
renderCart();renderInventory();renderReports();renderRequests(false);databaseStatus();
initBluetoothPrintSettings();
