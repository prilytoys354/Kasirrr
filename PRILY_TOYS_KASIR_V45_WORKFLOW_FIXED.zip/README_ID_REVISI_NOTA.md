PRILY TOYS KASIR V42 - Revisi Nota

Perubahan cetak nota:
- Kolom Qty dipisahkan dari Nama Barang dengan jarak yang jelas.
- Format dibuat 32 karakter agar lebih cocok untuk printer thermal 58 mm.
- Harga yang dicetak per item adalah subtotal.
- Simbol @ dan harga satuan tidak dicetak.
