# PRILY TOYS KASIR V36 — PRINTER LEBIH STABIL

Perbaikan utama:
- Nota tetap tampil setelah simpan/cetak; tombol Nota Baru yang mengosongkan nota.
- Nota yang sama dalam 60 detik tidak menggandakan omset; cetak ulang tetap boleh.
- Printer Bluetooth yang berhasil dipakai disimpan berdasarkan alamat Bluetooth dan dipakai otomatis pada cetak berikutnya.
- Koneksi mencoba SPP secure, SPP insecure, lalu RFCOMM channel 1.
- Data cetak dikirim bertahap dan diberi waktu buffer agar printer thermal murah tidak kehilangan data.
- Menghapus command density/speed vendor-specific yang pada sebagian printer generik dapat menyebabkan karakter aneh seperti hanya huruf/simbol.
- Encoding teks Latin dibuat lebih kompatibel (Windows-1252) dan karakter non-ASCII yang rawan diganti.
- Perintah auto-cut dihilangkan agar printer tanpa cutter tidak salah merespons.
- Format nota 76 mm dan harga rata kanan dipertahankan.


V37: cetak lebih tebal/gelap menggunakan ESC/POS emphasized + double-strike, tanpa command density vendor-specific.


## V38 — Input Barcode
- Kasir memiliki kolom Scan/Input Barcode.
- Barcode terdaftar otomatis mengisi nama dan harga.
- Barcode belum terdaftar tetap dapat diproses dengan input nama dan harga manual.
- Barcode disimpan sebagai data internal dan tidak dicetak pada nota.
- Nota menampilkan JUMLAH ITEM berdasarkan total qty.
- Ikon Nota Baru diperkuat agar fungsi kosongkan nota tetap bekerja.
